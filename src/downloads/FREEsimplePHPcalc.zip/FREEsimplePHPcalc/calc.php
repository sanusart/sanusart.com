<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <title>Calculator</title>
    <link rel="stylesheet" href="calcstyle.css" type="text/css" />
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
<!--
 * Simple calculator: calc.php 
 * Author: Sasha Khamkov
 * e-mail: contact@sanusart.com, scamme@gmail.com
 * web site: http://www.sanusart.com 
 *  
 * Please leave this notion as it is. 
 * Copyright (c) 2007 Sanus|artificium 
-->     

  </head>
  <body>
  <center>
  <div class="topbox"><b>Simple calculator</b></div>
    <form method="get" action="calcaction.php">
      <b>1st</b> Number:<br />
      <input class="textbox" type="text" name="number1" /><br /> 
      <b>2nd</b> Number:<br />
      <input class="textbox" type="text" name="number2" /><br /> 
      <b>Operation:</b><br /> 
      <input class="button" type="submit" name="op" value="+" />
      <input class="button" type="submit" name="op" value="-" />
      <input class="button" type="submit" name="op" value="x" />
      <input class="button" type="submit" name="op" value="/" />
      <input class="cbutton" style="color:#ff0000;" type="submit" name="op" value="C" />
    </form>   
<div class="bottombox">The answer is: <b><?php include('ans.html'); ?></b></div>    
    </center>
  </body>
</html>
