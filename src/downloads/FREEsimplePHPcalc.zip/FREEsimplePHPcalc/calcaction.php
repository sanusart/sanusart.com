<?php

/************************************
 Form action document for calc.php: calcaction.php
 Author: Sasha Khamkov
 e-mail: contact@sanusart.com, scamme@gmail.com
 web site: http://www.sanusart.com 
  
 Please leave this notion as it is. 
 Copyright (c) 2007 Sanus|artificium
*************************************/

$number1 = $_GET['number1'];
$number2 = $_GET['number2'];
$op = $_GET['op'];

// start of "+" operation

if ( $op == "+" ) 
{
  $filename = 'ans.html';
$answare = $number1+$number2;

// Checking of writability of the "ans.html" file,
// don't forget to CHMOD it to value 
// of 777 e.g. rwx.rwx.rwx.
if (is_writable($filename)) {

    // The data in the "ans.html" will be 
    // overwrited with every new calulation.
    if (!$handle = fopen($filename, 'r+')) {
         echo "Cannot open file ($filename)";
         exit;
    }

    // Write $answare data to "ans.html" file.
    if (fwrite($handle, $answare) === FALSE) {
        echo "Cannot write to file ($filename)";
        exit;
    }
    // Redirecting the data to the main 
    // "calc.php" page to be displayed.
    echo ('<meta http-equiv="refresh" content="0;url=calc.php" />');

    fclose($handle);

} else {
    echo "The file $filename is not writable";
}
}


// start of "-" operation

if ( $op == "-" ) 
{
  $filename = 'ans.html';
$answare = $number1-$number2;

// Checking of writability of the "ans.html" file,
// don't forget to CHMOD it to value 
// of 777 e.g. rwx.rwx.rwx.
if (is_writable($filename)) {

    // The data in the "ans.html" will be 
    // overwrited with every new calulation.
    if (!$handle = fopen($filename, 'r+')) {
         echo "Cannot open file ($filename)";
         exit;
    }

    // Write $answare data to "ans.html" file.
    if (fwrite($handle, $answare) === FALSE) {
        echo "Cannot write to file ($filename)";
        exit;
    }
    // Redirecting the data to the main 
    // "calc.php" page to be displayed.
    echo ('<meta http-equiv="refresh" content="0;url=calc.php" />');

    fclose($handle);

} else {
    echo "The file $filename is not writable";
}
}

// start of "x" operation

if ( $op == "x" ) 
{
$filename = 'ans.html';
$answare = $number1*$number2;

// Checking of writability of the "ans.html" file,
// don't forget to CHMOD it to value 
// of 777 e.g. rwx.rwx.rwx.
if (is_writable($filename)) {

    // The data in the "ans.html" will be 
    // overwrited with every new calulation.
    if (!$handle = fopen($filename, 'r+')) {
         echo "Cannot open file ($filename)";
         exit;
    }

    // Write $answare data to "ans.html" file.
    if (fwrite($handle, $answare) === FALSE) {
        echo "Cannot write to file ($filename)";
        exit;
    }
    // Redirecting the data to the main 
    // "calc.php" page to be displayed.
    echo ('<meta http-equiv="refresh" content="0;url=calc.php" />');

    fclose($handle);

} else {
    echo "The file $filename is not writable";
}
}

// start of "/" operation

if ( $op == "/" ) 
{
$filename = 'ans.html';
$answare = $number1/$number2;

// Checking of writability of the "ans.html" file,
// don't forget to CHMOD it to value 
// of 777 e.g. rwx.rwx.rwx.
if (is_writable($filename)) {

    // The data in the "ans.html" will be 
    // overwrited with every new calulation.
    if (!$handle = fopen($filename, 'r+')) {
         echo "Cannot open file ($filename)";
         exit;
    }

    // Write $answare data to "ans.html" file.
    if (fwrite($handle, $answare) === FALSE) {
        echo "Cannot write to file ($filename)";
        exit;
    }
    // Redirecting the data to the main 
    // "calc.php" page to be displayed.
    echo ('<meta http-equiv="refresh" content="0;url=calc.php" />');

    fclose($handle);

} else {
    echo "The file $filename is not writable";
}
}

// start of "C" operation
// This will empty the numbers fields 
// and place the "_" sign at the "ans.html" file
// by resetting the whole "calc.php" page.

if ( $op == "C" ) 
{
$filename = 'ans.html';
$answare = "_";

// Checking of writability of the "ans.html" file,
// don't forget to CHMOD it to value 
// of 777 e.g. rwx.rwx.rwx.
if (is_writable($filename)) {

    // The data in the "ans.html" will be 
    // overwrited with every new calulation.
    if (!$handle = fopen($filename, 'wb')) {
         echo "Cannot open file ($filename)";
         exit;
    }

    // Write $answare data to "ans.html" file.
    if (fwrite($handle, $answare) === FALSE) {
        echo "Cannot write to file ($filename)";
        exit;
    }
    // Redirecting the data to the main 
    // "calc.php" page to be displayed.
    echo ('<meta http-equiv="refresh" content="0;url=calc.php" />');

    fclose($handle);

} else {
    echo "The file $filename is not writable";
}
}

?>
