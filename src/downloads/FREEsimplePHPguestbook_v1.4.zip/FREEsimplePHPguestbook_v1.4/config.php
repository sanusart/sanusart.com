<?php
// Please choose language to use. 
// Language file must exist at 'lang' directory and named as acordingly.
$cfg['lang'] = 'en'; // will use 'en.php' file from 'lang' directory.

// Set date format. Reffere to http://php.net/manual/en/function.date.php for more info
$cfg['date_format'] = 'd/m/Y H:i'; // example output: 26/05/2010 10:23

// Words considdered as spam will trigger error and ask poster to fix it.
$cfg['spam_words'] = 'porn|pussy|xxx|blowjob|cock|sex|sexy|fuck|viagra|php|boobs|babes|passthru';

if (file_exists('lang/'.$cfg['lang'].'.php')) {
	include('lang/'.$cfg['lang'].'.php');
}
else {
	include('lang/en.php');
}

// functions.
function clean($str) {
	$str = stripslashes ( $str );
	$str = htmlentities ( $str );
	$str = strip_tags ( $str );
	return $str;
}
?>
