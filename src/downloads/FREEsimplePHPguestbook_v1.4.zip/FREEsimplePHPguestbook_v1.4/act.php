<?php
include ('config.php');
// Get the data from the 'Name' field of the form.
$data .= '<b>'.$lang['posted_by'].':</b> '.$_POST['name'].' <b>'.$lang['on'].':</b> '.date($cfg['date_format']).'<br />';

// Get the data from the 'site' field of the form.
$data .= '<b>'.$lang['website'].': </b>'.'<a href="http://'.$_POST['site'].'">'.$_POST['site'].'</a>'.'<br />';

// Get the data from the 'Message' field of the form.
$data .= '<p><b>'.$lang['message'].': </b><br />'.clean($_POST["message"]).'</p><hr />';  

// Specifications of the "bad words", spam, in the 'Message' field.
$spam = '/('.$cfg['spam_words'].')/i';
if (empty($_POST['name']) || empty($_POST['site']) || empty($_POST["message"]))
{
echo ('<br /><br /><center><div style="font-family:verdana,arial,san-serif;font-size:12px;border:5px groove #cc0000;height:50px;width:300px;padding:5px 5px 5px 55px;background:#ffffff url(error.jpg) no-repeat left;">'.$lang['empty_fields_error'].'</div></center>');
}

// Detects the $spam word and displays it in the warning.
elseif (preg_match($spam,$_POST["message"],$matches))
{
echo ('<br /><br /><center><div style="font-family:verdana,arial,san-serif;font-size:12px;border:5px groove #cc0000;height:50px;width:300px;padding:5px 5px 5px 55px;background:#ffffff url(error.jpg) no-repeat left;">'.sprintf($lang['spam_error'],$matches[1]).'</div></center>');
}
else
{

// Check if the captcha image verified.
session_start();
if ($_POST["img_ver"] != $_SESSION["img_ver"] || $_SESSION["img_ver"]=='')
{
echo('<br /><br /><center><div style="font-family:verdana,arial,san-serif;font-size:12px;border:5px groove #cc0000;height:50px;width:300px;padding:5px 5px 5px 55px;background:#ffffff url(error.jpg) no-repeat left;">'.$lang['captcha_error'].'</div></center>');
}
else
{

// The file to write $data to (don't forget to CHMOD it to 666).
$file = "messages.txt";   
if (!$file_handle = fopen($file,"a+")) 
{ 
echo $lang['cannot_open_file']; 
}  
if (!fwrite($file_handle,stripslashes(html_entity_decode($data))))
{ 
echo $lang['file_is_not_writable']; 
}     
fclose($file_handle);  
echo ('<br /><br /><center><div style="font-family:verdana,arial,san-serif;font-size:12px;border:5px groove #00cc00;height:50px;width:300px;padding:5px 5px 5px 55px;background:#ffffff url(ok.jpg) no-repeat left;">'.$lang['success'].'</div></center>');
echo ('<meta http-equiv="Refresh" content="4;url=guestbook.php" />');
}
}
?>
