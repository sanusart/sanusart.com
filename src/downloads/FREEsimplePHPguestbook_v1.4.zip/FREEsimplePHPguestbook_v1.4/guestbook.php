<?php 
include ('config.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=utf-8" />
    <meta name="robots" content="noindex,nofollow" />
    <link rel="stylesheet" href="style.css" type="text/css" />
    <title><?php echo $lang['title']?>
    </title>
  </head>
  <body>
<!--
Free PHP guestbook script.
Author: Sasha Khamkov
Downloaded from: http://www.sanusart.com
Copyright © 2007 Sanus|artificium
-->

<!-- This add is NOT included in the downloaded guestbook -->
<div style="width:500px;
   height:auto;
   margin:20px auto 20px auto;
   background:#ffffff;
   border:1px solid #cccccc;
   padding:5px 5px 5px 60px;">
<script type="text/javascript"><!--
google_ad_client = "pub-2905828856053063";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2007-08-09: testpage - Guestbook
google_ad_channel = "3288077734";
google_color_border = "FFFFFF";
google_color_bg = "FFFFFF";
google_color_link = "920909";
google_color_text = "808080";
google_color_url = "003090";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>

    <div id="main">
      <h1><?php echo $lang['header']?>:</h1>
      <form action="act.php" method="post">
        <?php echo $lang['name']?> <span style="font-weight:100;">(<?php echo $lang['required']?>)</span>:<br />
        <input class="textfield" type="text" name="name" value="" /><br />
        <?php echo $lang['website']?> <span style="font-weight:100;">(<?php echo $lang['without_http'];?>)</span>:<br />
        <input class="textfield" type="text" name="site" value="" /><br />
        <?php echo $lang['message']?>:<br />
<textarea class="textarea" rows="2" cols="25" name="message"></textarea><br />
<img src="img_ver.php" alt="Image verification" />  <br />
  <?php echo $lang['value_from_the_image'];?>:<br />
<input class="textfield" type="text" name="img_ver" value="" /><br />
        <input type="reset" name="reset" value="<?php echo $lang['reset'];?>" />
        <input type="submit" name="send" value="<?php echo $lang['send'];?>" />
      </form>
      <h1><?php echo $lang['the_messages'];?>:</h1>
      
        <?php include('messages.txt'); ?>
    </div>
    
    <!-- This add is NOT included in the downloaded guestbook -->
<div style="width:500px;
   height:auto;
   margin:20px auto 20px auto;
   background:#ffffff;
   border:1px solid #cccccc;
   padding:5px 5px 5px 60px;">
<script type="text/javascript"><!--
google_ad_client = "pub-2905828856053063";
google_ad_width = 468;
google_ad_height = 60;
google_ad_format = "468x60_as";
google_ad_type = "text_image";
//2007-08-09: testpage - Guestbook
google_ad_channel = "3288077734";
google_color_border = "FFFFFF";
google_color_bg = "FFFFFF";
google_color_link = "920909";
google_color_text = "808080";
google_color_url = "003090";
//-->
</script>
<script type="text/javascript"
  src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
    
  </body>
</html>
