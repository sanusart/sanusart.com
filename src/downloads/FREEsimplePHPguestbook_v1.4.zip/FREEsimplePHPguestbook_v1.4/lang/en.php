<?php
$lang['title'] = 'GUESTBOOK TEST PAGE';
$lang['posted_by'] = 'Posted by';
$lang['header'] = 'You are welcome to TEST the guestbook';
$lang['required'] = 'required';
$lang['without_http'] = 'without http://';
$lang['name'] = 'Name';
$lang['website'] = 'Web site';
$lang['message'] = 'Message';
$lang['on'] = 'on';
$lang['value_from_the_image'] = 'Please insert value from the image above';
$lang['the_messages'] = 'The messages';
$lang['send'] = 'Send';
$lang['reset'] = 'Reset';
$lang['cannot_open_file'] = 'Cannot open file';
$lang['file_is_not_writable'] = 'File is not writable';
$lang['empty_fields_error'] = '<b>Name</b> and <b>Message</b> fields cannot be empty!<br />Please go back and fix it.';
$lang['spam_error'] = 'SPAM filter detected forbiden word!<br /> The word is: <b> %s </b><br />Please go back and fix it.';
$lang['captcha_error'] = 'You did not entered the <b>image verification</b> correctly.<br /> Please go back and fix it.';
$lang['success'] = 'You have successfuly signed the guestbook.<br />Thank you!';
?>
