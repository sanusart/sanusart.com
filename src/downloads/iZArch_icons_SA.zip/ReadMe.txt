Sanus|artificium icon pack for iZArc

Icons sizes (in one file):
128x128
96x96
72x72
64x64
48x48
32x32
24x24
16x16

PNG size:
256x256

Sources:
Base GIMP project files included

Made of:
Grapgics - GIMP, blender
Convertion - AveIconifier2
Font - BorisBlackBloxx

License:
Feel free to use, edit, and redestribute but not to edit and redistribute as your own. 
Copyright (c) 2007 Sasha Khamkov | www.sanusart.com | contact@sanusart.com

Edited by:
No one yet.